# Roadmap dashboard

A self-hosted roadmap dashboard — Timeline (gantt), List, Board (kanban),
Operations, and Metrics — rendered from a single data file you control.

Built as an original implementation. It is not derived from, and shares no code
with, any third-party roadmap product.

- **No build step.** No npm, no bundler, no framework. Open `index.html`.
- **No dependencies.** Three files: HTML, one stylesheet, one script.
- **One source of truth.** Everything comes from `data/roadmap.js`. Add a task
  once and it appears in the Timeline, the List and the Board.

---

## ⚠️ Before you push: this repo contains real revenue and headcount data

`data/roadmap.js` ships with actual ARR figures, forecasts and employee names.

- **Make the repo private.** See step 2 below.
- On GitHub's **free** tier, a GitHub Pages site is public *even when published
  from a private repo*. If you want the page itself access-controlled, use
  Vercel or Netlify with password protection / SSO, or a GitHub Team plan.
- If you'd rather ship this publicly, replace the numbers and names in
  `data/roadmap.js` with placeholders first.

---

## 1. Run it locally

Clone or download the folder, then just open `index.html` in a browser.
It works straight off the filesystem — the data is loaded via a `<script>` tag,
not `fetch`, so there's no CORS problem and no local server needed.

If you'd prefer a server anyway (useful for testing relative paths as they'll
behave once deployed):

```bash
cd roadmap-dashboard
python3 -m http.server 8000
# then open http://localhost:8000
```

## 2. Create your GitHub repo

**Web UI**

1. Go to <https://github.com/new>
2. Repository name: `roadmap-dashboard`
3. Visibility: **Private**
4. Do **not** tick "Add a README" — this folder already has one
5. Create repository, then copy the HTTPS URL it shows you

**Or with the `gh` CLI**

```bash
gh repo create roadmap-dashboard --private --source=. --remote=origin
```

## 3. Push this folder

```bash
cd roadmap-dashboard
git init
git branch -M main
git add .
git commit -m "Add roadmap dashboard"
git remote add origin https://github.com/YOUR-USERNAME/roadmap-dashboard.git
git push -u origin main
```

The first push will ask you to authenticate. GitHub doesn't accept your account
password here — use the Git Credential Manager, or create a fine-grained
Personal Access Token (GitHub → Settings → Developer settings → Personal access
tokens) and paste that when prompted for a password.

## 4. The everyday loop

```bash
# edit data/roadmap.js
git add .
git commit -m "Sprint 10 planning"
git push
```

## 5. Deploy

| Host | How | Private page? |
|---|---|---|
| **GitHub Pages** | Repo → Settings → Pages → Deploy from branch → `main` / `root` | Public on the free tier, even from a private repo |
| **Vercel** | Import the repo at vercel.com — no framework preset, output dir `.` | Yes, via Deployment Protection |
| **Netlify** | New site from Git — no build command, publish dir `.` | Yes, via password protection |

All three redeploy automatically on every `git push`.

---

## 6. Putting it on a page inside a bigger site

Two options, depending on how that site is built.

**A. Iframe (works with any site — WordPress, Webflow, Squarespace, a static
site, anything).** Deploy this repo on its own, then embed:

```html
<iframe src="https://your-dashboard.vercel.app/#timeline"
        style="width:100%;height:900px;border:0" title="Roadmap"></iframe>
```

Deep links work: `#timeline`, `#list`, `#board`, `#operations`, `#metrics`.
This keeps the two codebases independent, which is usually what you want.

**B. Drop it into the bigger site's own repo.** Copy `index.html`,
`assets/` and `data/` into a new route folder (e.g. `/roadmap/`), fix the
three relative paths in `index.html` if your host rewrites URLs, and let the
parent site's nav link to it. Choose this if the dashboard needs the site's
header, auth, or design system around it.

If that bigger site is React/Next.js/Vue and you'd rather have this as a real
component than an iframe, the split is already component-shaped: `renderTimeline`,
`renderList`, `renderBoard`, `renderOps`, `renderMetrics` in `assets/app.js` are
independent and each own one DOM node.

---

## 7. Editing the data

`data/roadmap.js` is the only file you touch week to week. It has inline
comments, but the shape is:

| Key | What it drives |
|---|---|
| `meta.today` | Freeze the dashboard to a reporting date, or `null` for the real today |
| `goal` | The hero number in the header and on Metrics |
| `teams` | Initiatives, their targets, and their colour slot |
| `timelineTeams` | Which teams get a Timeline swimlane, in order |
| `sprints` | Sprint boundaries — the Timeline's columns |
| `people` | Names, teams, roles, and who's `available` |
| `tasks` | Every card. Feeds Timeline + List + Board at once |
| `milestones` | The Operations milestone list |
| `metrics` | The monthly log table |
| `trackedGoals` | The progress cards and sparklines under it |

### Adding a task

```js
{ id: "t-200", title: "Ship the thing", note: "why it matters",
  team: "core", status: "progress", people: ["yann"],
  start: "2026-09-01", end: "2026-09-12",
  subtasks: { done: 1, total: 3 }, ref: "PLA-900" },
```

Valid `status` values: `request`, `none`, `backlog`, `committed`, `design`,
`ready`, `progress`, `done`.

### Board column counts

`boardTotals` lets a column header read "21 of 34" when your real system holds
more items than you've listed here. Set an entry to `null` to just count what's
in the file. The column footer says plainly how many aren't itemised — no
silent truncation.

### Adding a team

Add it to `teams` with the next unused `slot` number (1–8). Slots map to a
validated categorical palette; **don't reuse a slot** — two teams sharing one
colour is the one thing that makes these views unreadable. Past eight teams,
use `slot: "other"`, which renders a neutral grey.

---

## 8. Colour and accessibility notes

The palette isn't decorative, so it's worth knowing before you change it:

- **Team colours** are 8 fixed categorical slots, ordering chosen so that
  adjacent pairs stay distinguishable under protanopia/deuteranopia/tritanopia.
  Both light and dark are separately selected steps, not an automatic flip.
- **Status colours are reserved** and never reused as a team colour. Workflow
  states run along an ordinal blue ramp (committed → in design → ready),
  in-progress is the warning amber, done is the success green, overdue is the
  critical red.
- **Colour never carries meaning alone.** Every status pill has an icon and a
  text label; every team dot sits beside the team's name.
- The availability meter and the sparklines both have their numbers written out
  beside them, and the Metrics table is the table view for the sparklines.

If you re-colour this for a brand, keep those properties — swap the eight
`--series-*` values in `assets/styles.css` and re-check the adjacent pairs.

---

## 9. What's deliberately not here

- **No backend.** The data is a file in git; history is your audit log.
- **No drag-and-drop.** Moving a card means editing a date in the data file.
  This is a reporting surface, not a replacement planning tool.
- **No auto-sync.** If the numbers live in another system, the next step is a
  script that writes `data/roadmap.js` — the format was designed to be
  machine-generated.

## Layout

```
roadmap-dashboard/
├── index.html          page shell + nav
├── assets/
│   ├── styles.css      all styling, colour roles at the top
│   └── app.js          all rendering, one function per view
├── data/
│   └── roadmap.js      ← the only file you edit
└── README.md
```
